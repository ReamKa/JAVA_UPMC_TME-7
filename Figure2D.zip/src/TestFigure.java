public class TestFigure {

    private static Figure2D[] tableauDeFigure;

    public static void main (String[] args) {

        tableauDeFigure = new Figure2D[4];

        tableauDeFigure[0] = new Carre(1.0, 2.0);
        tableauDeFigure[1] = new Cercle(3);
        tableauDeFigure[2] = new Ellipse(4, 5);
        tableauDeFigure[3] = new Rectangle(6, 7);

        for (int i = 0 ; i < tableauDeFigure.length; i++) {
            System.out.println("Le perimetre  est : " + tableauDeFigure[i].perimetre());
            System.out.println("La surface est : " + tableauDeFigure[i].surface());
        }

        }
    }

