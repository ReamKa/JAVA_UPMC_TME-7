public class Carre extends Rectangle {

    public Carre(double longueur, double largeur) {
        super(longueur, largeur);
    }
}

