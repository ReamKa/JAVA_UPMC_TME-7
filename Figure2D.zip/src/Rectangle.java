
public class Rectangle extends Figure2D {
    protected double longueur, largeur;

    public Rectangle(double longueur, double largeur) {
        this.longueur = longueur;
        this.largeur = largeur;
    }
    public double surface (){
        return longueur * largeur;
    }
    public double perimetre() {
        return (longueur + largeur) * 2;
    }
}
