public class Cercle extends Ellipse {

    public Cercle(double rayon) {
        super(rayon, rayon);
    }
}
