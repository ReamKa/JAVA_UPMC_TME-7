public class Ellipse extends Figure2D{
    protected double a,b;

    public Ellipse(double a, double b){
        this.a = a;
        this.b = b;

    }
    public double perimetre() {
        return Math.round(2 * Math.PI * Math.sqrt((Math.pow(a,2) + Math.pow(b,2)) / 2));
    }
    public double surface(){
        return Math.round(Math.PI * a * b);
    }
}
