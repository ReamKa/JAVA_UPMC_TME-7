public abstract class APattes extends Animal{
    protected int nbPattes;

   public APattes(String nom, int age, int nbPattes){
       super(nom,age);
       this.nbPattes = nbPattes;
   }

    @Override
    public String toString() {
        return super.toString() + ". Nombre de pattes : " + nbPattes;
    }
}
