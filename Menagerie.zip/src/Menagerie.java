public class Menagerie {
    Animal [] tableauDAnimal;
    int nbAnimal = 0;

    public Menagerie(int tailleTableau){
        tableauDAnimal = new Animal[tailleTableau];
    }
    public void ajouter(Animal animal){
        tableauDAnimal[nbAnimal] = animal;
        nbAnimal ++;
    }
    public String toString() {
        String liste = "";
        for (int j = 0; j < nbAnimal; j++) {
            liste += tableauDAnimal[j] + "\n";
        }
        return liste;
    }
    public void midi(){
        for (int j = 0; j < nbAnimal ; j++) {
            System.out.println(tableauDAnimal[j].crier());
        }
    }
    public void vieillirTous() {
        for (int index = 0; index < nbAnimal; index++)
            tableauDAnimal[index].vieillir();
    }
}

