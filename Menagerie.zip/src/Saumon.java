public class Saumon extends Animal {
    String cri =  "glouglou";

    public Saumon(String nom, int age){
        super(nom,age);
    }
    public String toString(){
        return "Nom: " + nom + ". Age : " + age + ".";
    }
    @Override
    public String crier() {
        return cri;
    }
}
