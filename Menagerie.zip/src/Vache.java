public class Vache extends APattes {
    private String cri = "MEEEEEUUUUUH";

    public Vache(String nom, int age){
        super(nom,age,4);
    }
    public String toString(){
        return "Nom: " + nom + ". Age : " + age + ". Nombres de pattes: " + nbPattes;
    }
    public String crier(){
        return cri;
    }
}
