public abstract class SansPattes extends Animal {

    public SansPattes(String nom, int age){
        super(nom,age);
    }

    @Override
    public String toString() {
        return super.toString() + ". Aucune patte.";
    }
}
