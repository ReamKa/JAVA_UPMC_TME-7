public class MillePattes extends APattes {
    String cri = "tititiitititititiititk";

    public MillePattes(String nom, int age){
        super(nom, age, 20000);
    }
    public String toString(){
        return "Nom: " + nom + ". Age : " + age + ". Nombres de pattes: " + nbPattes;
    }
    @Override
    public String crier() {
        return cri;
    }
}
