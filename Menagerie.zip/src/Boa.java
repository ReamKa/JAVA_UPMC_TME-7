public class Boa extends SansPattes {
    String cri = "psssssss";

    public Boa (String nom, int age){
        super(nom,age);
    }
    public String toString(){
        return "Nom: " + nom + ". Age : " + age + ".";
    }
    public String crier(){
        return  cri;
    }
}

