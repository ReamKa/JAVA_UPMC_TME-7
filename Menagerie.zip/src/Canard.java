public class Canard extends APattes{
    String cri = "KOING KOING";

    public Canard(String nom, int age){
        super(nom,age,2);
    }
    public String toString(){
        return "Nom: " + nom + ". Age : " + age + ". Nombres de pattes: " + nbPattes;
    }
    @Override
    public String crier() {
        return cri;

    }
}
