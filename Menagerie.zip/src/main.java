public class main {
    public static void main (String[] args){

        Menagerie m = new Menagerie(10);
        Animal salomon = new Bebe("Salomon");
        Animal serpent = new Boa("serpent du sheitan",4);
        Animal canard = new Canard("canarde",6);
        Animal millepates = new MillePattes("mimi",8);
        Animal saumon = new Saumon("FiletOFish",6);
        Animal vache = new Vache("Vache Qui Rit",18);

        m.ajouter(salomon);
        m.ajouter(serpent);
        m.ajouter(canard);
        m.ajouter(millepates);
        m.ajouter(saumon);
        m.ajouter(vache);

        m.midi();

        m.vieillirTous();

        System.out.println(m.toString());
    }
}
