public class Bebe extends SansPattes{
    //Un bebe est une larve, ca sait ni changer sa couche, ni se faire à manger. Ca fait que gueuler et faire caca
    String cri = "OUIIIIIINNN";
    public Bebe(String nom){
        super(nom,1);
    }
    public String toString(){
        return "Nom: " + nom + ". Age : " + age + ".";
    }
    public String crier(){
        return cri;
    }
}
